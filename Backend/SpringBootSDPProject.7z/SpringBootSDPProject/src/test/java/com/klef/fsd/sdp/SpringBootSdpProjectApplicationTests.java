package com.klef.fsd.sdp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootSdpProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
